if (typeof firebase === 'undefined') throw new Error('hosting/init-error: Firebase SDK not detected. You must include it before /__/firebase/init.js');
firebase.initializeApp({
  "apiKey": "AIzaSyDaVvoX75T8LBoRSqmUq82ILb0qnLOtRDU",
  "appId": "1:271248187848:web:fbfcb3b5f8a012bae6a0fd",
  "authDomain": "ygo-synapse.firebaseapp.com",
  "databaseURL": "",
  "measurementId": "G-W5XG17JD3C",
  "messagingSenderId": "271248187848",
  "projectId": "ygo-synapse",
  "storageBucket": "ygo-synapse.firebasestorage.app"
});